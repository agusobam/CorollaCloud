# CorollaCloud v0.1

CorollaCloud is a small cloud encoder laboratory for the Corolla MBG experiment.

## Current MVP
- Mobile-friendly web UI.
- Upload video to cloud.
- Run one HEVC/x265 experiment remotely.
- FFprobe metadata analysis.
- Frame-structure analysis (I/P/B/other, max B-run).
- Download encoded result.

## Server
The server uses FastAPI + FFmpeg inside Docker. The first version intentionally supports `libx265` only so the API/UI can be validated before adding more encoders.

## Deploy
Deploy the `server` directory as a Docker web service. The included `render.yaml` is a starting point for Render.

For temporary laboratory files, the app uses `/data`. Add persistent storage later if you want results to survive restarts. Otherwise, treat jobs/results as temporary.

## Next phase
- Add Kvazaar support to the image/build.
- Add reference-video upload and automatic distance scoring against the Corolla MBG fingerprint.
- Add batch search (GOP/B-frame/ref/etc.).
- Add job history and candidate ranking without making a subjective visual-quality claim.
- Build an Android Sketchware client that calls the API so the browser UI is not needed.
