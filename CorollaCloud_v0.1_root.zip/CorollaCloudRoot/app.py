import json
import os
import re
import shutil
import subprocess
import threading
import uuid
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel, Field

BASE = Path(os.getenv("COROLLA_DATA", "/data"))
INPUTS = BASE / "inputs"
JOBS = BASE / "jobs"
INPUTS.mkdir(parents=True, exist_ok=True)
JOBS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="CorollaCloud", version="0.1.0")

jobs: dict[str, dict[str, Any]] = {}
jobs_lock = threading.Lock()


def run_cmd(args: list[str], timeout: int = 3600) -> tuple[int, str, str]:
    p = subprocess.run(
        args,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )
    return p.returncode, p.stdout, p.stderr


def safe_name(name: str) -> str:
    name = Path(name or "video.mp4").name
    name = re.sub(r"[^A-Za-z0-9._-]", "_", name)
    return name or "video.mp4"


def ffprobe_json(path: Path, frames: bool = False) -> dict[str, Any]:
    if frames:
        args = [
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-select_streams", "v:0",
            "-show_frames",
            "-show_entries", "frame=pict_type,key_frame",
            str(path),
        ]
    else:
        args = [
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_streams", "-show_format", str(path)
        ]
    rc, out, err = run_cmd(args, timeout=1800)
    if rc != 0:
        raise RuntimeError(err[-4000:] or "ffprobe failed")
    return json.loads(out or "{}")


def stream_summary(path: Path) -> dict[str, Any]:
    data = ffprobe_json(path)
    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), {})
    audio = next((s for s in streams if s.get("codec_type") == "audio"), {})
    fmt = data.get("format", {})

    def val(d: dict[str, Any], key: str):
        return d.get(key)

    return {
        "codec": val(video, "codec_name"),
        "profile": val(video, "profile"),
        "tag": val(video, "codec_tag_string"),
        "width": val(video, "width"),
        "height": val(video, "height"),
        "pix_fmt": val(video, "pix_fmt"),
        "fps": val(video, "r_frame_rate"),
        "avg_fps": val(video, "avg_frame_rate"),
        "time_base": val(video, "time_base"),
        "video_bitrate": int(video.get("bit_rate")) if str(video.get("bit_rate", "")).isdigit() else video.get("bit_rate"),
        "has_b_frames": val(video, "has_b_frames"),
        "refs": val(video, "refs"),
        "level": val(video, "level"),
        "colorspace": val(video, "color_space"),
        "primaries": val(video, "color_primaries"),
        "transfer": val(video, "color_transfer"),
        "range": val(video, "color_range"),
        "audio_codec": val(audio, "codec_name"),
        "audio_bitrate": int(audio.get("bit_rate")) if str(audio.get("bit_rate", "")).isdigit() else audio.get("bit_rate"),
        "format": val(fmt, "format_name"),
        "format_bitrate": int(fmt.get("bit_rate")) if str(fmt.get("bit_rate", "")).isdigit() else fmt.get("bit_rate"),
        "duration": val(fmt, "duration"),
        "size": int(fmt.get("size")) if str(fmt.get("size", "")).isdigit() else fmt.get("size"),
    }


def frame_summary(path: Path) -> dict[str, Any]:
    data = ffprobe_json(path, frames=True)
    frames = data.get("frames", [])
    counts = {"I": 0, "P": 0, "B": 0, "other": 0}
    max_run = 0
    run = 0
    positions: list[int] = []
    pattern: list[str] = []

    for idx, fr in enumerate(frames):
        t = fr.get("pict_type")
        if t in counts and t != "other":
            counts[t] += 1
            pattern.append(t)
            if t == "B":
                run += 1
                max_run = max(max_run, run)
            else:
                run = 0
            if t == "I":
                positions.append(idx)
        else:
            counts["other"] += 1
            pattern.append("?")
            run = 0

    return {
        "frames": len(frames),
        **counts,
        "max_b_run": max_run,
        "i_positions": positions[:100],
        "pattern": " ".join(pattern[:100]) + (" ..." if len(pattern) > 100 else ""),
    }


class Experiment(BaseModel):
    encoder: str = Field(default="libx265")
    bitrate: str = Field(default="733k")
    duration: int = Field(default=6, ge=1, le=120)
    bframes: int = Field(default=4, ge=0, le=16)
    b_adapt: int = Field(default=0, ge=0, le=2)
    b_pyramid: int = Field(default=0, ge=0, le=1)
    ref: int = Field(default=1, ge=1, le=8)
    keyint: int = Field(default=184, ge=1, le=1000)
    scenecut: int = Field(default=0, ge=0, le=1)


def build_x265_command(src: Path, out: Path, cfg: Experiment) -> list[str]:
    params = (
        f"bframes={cfg.bframes}:"
        f"b-adapt={cfg.b_adapt}:"
        f"b-pyramid={'normal' if cfg.b_pyramid else 'none'}:"
        f"ref={cfg.ref}:"
        f"keyint={cfg.keyint}:"
        f"min-keyint={cfg.keyint}:"
        f"scenecut={cfg.scenecut}"
    )
    return [
        "ffmpeg", "-y", "-v", "error",
        "-i", str(src),
        "-t", str(cfg.duration),
        "-map", "0:v:0", "-an",
        "-vf", "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,format=yuv420p,setsar=1",
        "-r", "30",
        "-c:v", cfg.encoder,
        "-pix_fmt", "yuv420p",
        "-profile:v", "main",
        "-x265-params", params,
        "-b:v", cfg.bitrate,
        "-tag:v", "hvc1",
        "-colorspace", "bt709",
        "-color_primaries", "bt709",
        "-color_trc", "bt709",
        str(out),
    ]


def do_experiment(job_id: str, src: Path, cfg: Experiment) -> None:
    work = JOBS / job_id
    out = work / "result.mp4"
    try:
        with jobs_lock:
            jobs[job_id]["status"] = "running"
            jobs[job_id]["message"] = "Encoding..."

        if cfg.encoder != "libx265":
            raise RuntimeError("v0.1 currently supports encoder=libx265 only")

        cmd = build_x265_command(src, out, cfg)
        rc, stdout, stderr = run_cmd(cmd, timeout=max(1800, cfg.duration * 180))
        if rc != 0:
            raise RuntimeError(stderr[-8000:] or "FFmpeg failed")

        with jobs_lock:
            jobs[job_id]["message"] = "Analyzing metadata..."

        metadata = stream_summary(out)
        frames = frame_summary(out)

        with jobs_lock:
            jobs[job_id].update({
                "status": "done",
                "message": "Complete",
                "metadata": metadata,
                "frame_structure": frames,
                "result_url": f"/api/jobs/{job_id}/download",
            })
    except Exception as exc:
        with jobs_lock:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["message"] = str(exc)


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    rc, out, err = run_cmd(["ffmpeg", "-hide_banner", "-version"], timeout=30)
    enc_rc, enc_out, enc_err = run_cmd(["ffmpeg", "-hide_banner", "-encoders"], timeout=30)
    return {
        "ok": rc == 0,
        "ffmpeg": out.splitlines()[0] if out else err,
        "encoders": [line.strip() for line in enc_out.splitlines() if "hevc" in line.lower() or "x265" in line.lower()],
    }


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(400, "No filename")
    file_id = uuid.uuid4().hex
    dest = INPUTS / f"{file_id}_{safe_name(file.filename)}"
    with dest.open("wb") as f:
        while chunk := await file.read(1024 * 1024):
            f.write(chunk)
    return {"file_id": file_id, "filename": dest.name, "size": dest.stat().st_size}


@app.post("/api/experiment/{file_id}")
def experiment(file_id: str, cfg: Experiment):
    matches = list(INPUTS.glob(f"{file_id}_*"))
    if not matches:
        raise HTTPException(404, "Input file not found")

    job_id = uuid.uuid4().hex
    work = JOBS / job_id
    work.mkdir(parents=True, exist_ok=True)
    src = matches[0]

    with jobs_lock:
        jobs[job_id] = {
            "job_id": job_id,
            "status": "queued",
            "message": "Queued",
            "config": cfg.model_dump(),
        }

    threading.Thread(target=do_experiment, args=(job_id, src, cfg), daemon=True).start()
    return jobs[job_id]


@app.get("/api/jobs/{job_id}")
def job_status(job_id: str):
    with jobs_lock:
        item = jobs.get(job_id)
        if not item:
            raise HTTPException(404, "Job not found")
        return item


@app.get("/api/jobs/{job_id}/download")
def download(job_id: str):
    path = JOBS / job_id / "result.mp4"
    if not path.exists():
        raise HTTPException(404, "Result not ready")
    return FileResponse(path, media_type="video/mp4", filename="corolla_result.mp4")
